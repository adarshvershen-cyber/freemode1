# FreeMode Technologies website

A responsive static website prepared for GitHub Pages.

## Files
- `index.html` — page content, SEO title/description and Organization structured data
- `style.css` — responsive layout and visual design
- `script.js` — mobile navigation and WhatsApp enquiry form

## Before publishing
1. Open `script.js`.
2. Replace `REPLACE_WITH_WHATSAPP_NUMBER` with your WhatsApp number including country code, digits only. Example: `919876543210`.
3. Replace `REPLACE_WITH_OFFICIAL_EMAIL` with your official email address. (The email is currently a configuration placeholder; add it to the contact section in `index.html` if you want it displayed.)
4. In `index.html`, confirm the canonical URL `https://freemode.com/` is your actual domain. Change it if needed.
5. Verify the branch/service-area wording and course details before publishing.

## Publish with GitHub Pages
1. Create a GitHub repository (for example `freemode-website`).
2. Upload `index.html`, `style.css`, `script.js` to the repository root (not inside another nested folder).
3. Open repository **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then Save.
6. After deployment, GitHub will show your Pages URL.

## Connect a Hostinger domain
1. In GitHub **Settings → Pages → Custom domain**, enter your domain (for example `www.freemode.com`) and Save.
2. In Hostinger DNS Zone, configure the GitHub Pages A records for the apex/root domain:
   - `185.199.108.153`
   - `185.199.109.153`
   - `185.199.110.153`
   - `185.199.111.153`
   Set each record type to `A`, name/host to `@`.
3. Add a `CNAME` record: host/name `www`, target `YOUR-GITHUB-USERNAME.github.io` (replace with your GitHub username).
4. Remove only conflicting website A/AAAA/CNAME records. Do not delete email MX/TXT records used by your email service.
5. Wait for DNS propagation, return to GitHub Pages and enable **Enforce HTTPS** when available.

## Important
This is a static website. The enquiry form opens WhatsApp; it does not store submissions in a database. A working WhatsApp number must be configured in `script.js`.
