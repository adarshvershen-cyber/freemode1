/*
  FreeMode website settings
  1. Replace WHATSAPP_NUMBER with your WhatsApp number including country code.
     Example for India: 919876543210 (digits only, no + or spaces).
  2. Replace CONTACT_EMAIL with your official email address.
*/
const FREEMODE_CONFIG = {
  whatsappNumber: "REPLACE_WITH_WHATSAPP_NUMBER",
  contactEmail: "REPLACE_WITH_OFFICIAL_EMAIL"
};

const menuToggle = document.querySelector(".menu-toggle");
const mainNav = document.querySelector(".main-nav");

if (menuToggle && mainNav) {
  menuToggle.addEventListener("click", () => {
    const isOpen = mainNav.classList.toggle("open");
    menuToggle.setAttribute("aria-expanded", String(isOpen));
    menuToggle.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
  });

  mainNav.querySelectorAll("a").forEach(link => {
    link.addEventListener("click", () => {
      mainNav.classList.remove("open");
      menuToggle.setAttribute("aria-expanded", "false");
    });
  });
}

document.querySelectorAll("[data-course]").forEach(link => {
  link.addEventListener("click", () => {
    const interest = document.querySelector("#interest");
    if (interest) interest.value = link.dataset.course;
  });
});

const year = document.querySelector("#year");
if (year) year.textContent = new Date().getFullYear();

const enquiryForm = document.querySelector("#enquiry-form");
const feedback = document.querySelector("#form-feedback");

if (enquiryForm) {
  enquiryForm.addEventListener("submit", event => {
    event.preventDefault();

    const formData = new FormData(enquiryForm);
    const name = String(formData.get("name") || "").trim();
    const phone = String(formData.get("phone") || "").trim();
    const interest = String(formData.get("interest") || "").trim();
    const message = String(formData.get("message") || "").trim();

    if (!name || !phone || !interest) {
      feedback.textContent = "Please complete your name, phone number and area of interest.";
      return;
    }

    if (!/^\d{10,15}$/.test(FREEMODE_CONFIG.whatsappNumber)) {
      feedback.textContent = "The website owner needs to add the official WhatsApp number in script.js before enquiries can be sent.";
      return;
    }

    const text = [
      "Hello FreeMode Technologies,",
      "",
      "I would like to make an enquiry.",
      "Name: " + name,
      "Phone: " + phone,
      "Interested in: " + interest,
      message ? "Message: " + message : ""
    ].filter(Boolean).join("\n");

    const whatsappUrl = "https://wa.me/" + FREEMODE_CONFIG.whatsappNumber + "?text=" + encodeURIComponent(text);
    window.open(whatsappUrl, "_blank", "noopener,noreferrer");
    feedback.textContent = "WhatsApp opened. Please review your message and tap Send.";
  });
}
